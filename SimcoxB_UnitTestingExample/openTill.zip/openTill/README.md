openTill
========

openTill is an open source Point of Sales System developed around a user friendly environment for easy management of sales and inventory. Included is a database used for data collection and a User interface meant to be clean and easy to use.

>Copyright (C) &lt;2014&gt;  &lt;NMC Student Developer Consortium&gt;
openTill was created by the following students in course CIT275 under the leadership of instructor Jeff Straw:
-Bethany Beery
-Blaine Simcox	
-Cameron VanHouzen	
-Curtis Reinhold	
-Jeff Straw	
-Morgan Davis	
-Ryan Redburn	
-Shane Johnson	
-Steven Starlin	
-Zachary Tremain

>This program is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

>This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

>You should have received a copy of the GNU General Public License
along with this program.  If not, see <http://www.gnu.org/licenses/>.
