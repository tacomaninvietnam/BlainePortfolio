﻿using System.Windows;

namespace openTill.GUI.Views
{
    /// <summary>
    /// Description for TransactionLite.
    /// </summary>
    public partial class TransactionLite : Window
    {
        /// <summary>
        /// Initializes a new instance of the TransactionLite class.
        /// </summary>
        public TransactionLite()
        {
            InitializeComponent();
        }
    }
}