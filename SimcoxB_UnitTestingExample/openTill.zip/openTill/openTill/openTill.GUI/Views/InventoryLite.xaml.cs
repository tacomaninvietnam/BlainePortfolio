﻿using System.Windows;

namespace openTill.GUI.Views
{
    /// <summary>
    /// Description for InventoryLite.
    /// </summary>
    public partial class InventoryLite : Window
    {
        /// <summary>
        /// Initializes a new instance of the InventoryLite class.
        /// </summary>
        public InventoryLite()
        {
            InitializeComponent();
        }
    }
}